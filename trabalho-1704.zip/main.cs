using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

// Definição da classe Evento para representar um evento
class Evento
{
    // Propriedades do evento
    public string Id { get; set; }
    public string Titulo { get; set; }
    public DateTime Data { get; set; }
    public TimeSpan HoraInicial { get; set; }
    public TimeSpan HoraFinal { get; set; }
    public string Descricao { get; set; }
    public int QuantidadePessoas { get; set; }
    public string PublicoAlvo { get; set; }
    public Contato Responsavel { get; set; }
}

// Definição da classe Contato para representar um contato
class Contato
{
    // Propriedades do contato
    public string Nome { get; set; }
    public string Telefone { get; set; }
    public string Email { get; set; }
}

class Program
{
    static List<Evento> eventos = new List<Evento>(); // Lista para armazenar os eventos

    static void Main(string[] args)
    {
        // Loop principal do programa
        while (true)
        {
            MostrarMenu(); // Exibe o menu de opções
            string opcao = Console.ReadLine(); // Lê a opção escolhida pelo usuário
            ExecutarOpcao(opcao); // Executa a opção escolhida pelo usuário
        }
    }

    // Método para exibir o menu de opções
    static void MostrarMenu()
    {
        Console.WriteLine("Menu:");
        Console.WriteLine("1. Cadastrar Evento");
        Console.WriteLine("2. Listar Eventos");
        Console.WriteLine("3. Pesquisar Evento por Data");
        Console.WriteLine("4. Editar Evento");
        Console.WriteLine("5. Excluir Evento");
        Console.WriteLine("6. Pesquisar Contato");
        Console.WriteLine("7. Exportar Evento para TXT");
        Console.WriteLine("8. Sair");
        Console.Write("Escolha uma opção: ");
    }

    // Método para executar a opção escolhida pelo usuário
    static void ExecutarOpcao(string opcao)
    {
        switch (opcao)
        {
            case "1":
                CadastrarEvento(); // Chama para cadastrar um evento
                break;
            case "2":
                ListarEventos(); // Chama para listar os eventos
                break;
            case "3":
                PesquisarEventoPorData(); // Chama para pesquisar evento por data
                break;
            case "4":
                EditarEvento(); // Chama para editar um evento
                break;
            case "5":
                ExcluirEvento(); // Chama para excluir um evento
                break;
            case "6":
                PesquisarContato(); // Chama para pesquisar um contato
                break;
            case "7":
                ExportarEventoParaTxt(); // Chama para exportar um evento para TXT
                break;
            case "8":
                Environment.Exit(0); // Encerra o programa
                break;
            default:
                Console.WriteLine("Opção inválida! Tente novamente.");
                break;
        }
    }

    // Método para cadastrar um novo evento
    static void CadastrarEvento()
    {
        Evento evento = new Evento(); // Cria um novo evento
        evento.Id = GerarId(); // Gera um ID para o evento
        Console.WriteLine("Cadastro de Evento");
        Console.WriteLine("------------------");

        // Solicita e armazena os dados do evento
        evento.Titulo = LerString("Título do Evento: ");
        evento.Data = LerData("Data do Evento (dd/mm/aaaa): ");
        evento.HoraInicial = LerHora("Hora inicial do Evento (hh:mm): ");
        evento.HoraFinal = LerHora("Hora final do Evento (hh:mm): ");
        evento.Descricao = LerString("Descrição do Evento: ");
        evento.QuantidadePessoas = LerInt("Quantidade de Pessoas: ");
        evento.PublicoAlvo = LerString("Público Alvo: ");

        // Criar e preencher o contato do responsável
        evento.Responsavel = CriarContato();

        eventos.Add(evento); // Adiciona o evento à lista de eventos

        Console.WriteLine("------------------");
        Console.WriteLine("Evento cadastrado com sucesso!");
        Console.WriteLine("ID do Evento: " + evento.Id);
        Console.WriteLine("------------------");
    }

    // Método para criar um novo contato
    static Contato CriarContato()
    {
        Contato contato = new Contato();
        Console.WriteLine("Contato do Responsável");
        contato.Nome = LerString("Nome: ");
        contato.Telefone = LerString("Telefone: ");
        contato.Email = LerString("Email: ");
        return contato;
    }

    // Método para listar todos os eventos cadastrados
    static void ListarEventos()
    {
        Console.WriteLine("Listar Eventos");
        Console.WriteLine("------------------");

        foreach (var evento in eventos)
        {
            // Exibe as informações de cada evento
            Console.WriteLine($"ID: {evento.Id}, Título: {evento.Titulo}, Data: {evento.Data.ToShortDateString()}, Horário: {evento.HoraInicial.ToString()} - {evento.HoraFinal.ToString()}");
        }

        Console.WriteLine("------------------");
    }

    // Método para pesquisar um evento por data específica
    static void PesquisarEventoPorData()
    {
        Console.WriteLine("Pesquisar Evento por Data");
        Console.WriteLine("------------------");

        DateTime data = LerData("Data do Evento (dd/mm/aaaa): ");

        foreach (var evento in eventos)
        {
            if (evento.Data == data)
            {
                // Exibe as informações do evento encontrado
                Console.WriteLine($"ID: {evento.Id}, Título: {evento.Titulo}, Data: {evento.Data.ToShortDateString()}, Horário: {evento.HoraInicial.ToString()} - {evento.HoraFinal.ToString()}");
                return;
            }
        }

        Console.WriteLine("Nenhum evento encontrado para esta data.");
        Console.WriteLine("------------------");
    }

    // Método para editar as informações de um evento
    static void EditarEvento()
    {
        Console.WriteLine("Editar Evento");
        Console.WriteLine("------------------");

        string id = LerString("ID do Evento: ");
        Evento evento = eventos.Find(e => e.Id == id);

        if (evento == null)
        {
            Console.WriteLine("Evento não encontrado!");
            return;
        }

        Console.WriteLine("Informe os novos dados:");
        evento.Titulo = LerString("Título do Evento: ");
        evento.Data = LerData("Data do Evento (dd/mm/aaaa): ");
        evento.HoraInicial = LerHora("Hora inicial do Evento (hh:mm): ");
        evento.HoraFinal = LerHora("Hora final do Evento (hh:mm): ");
        evento.Descricao = LerString("Descrição do Evento: ");
        evento.QuantidadePessoas = LerInt("Quantidade de Pessoas: ");
        evento.PublicoAlvo = LerString("Público Alvo: ");

        evento.Responsavel = CriarContato();

        Console.WriteLine("------------------");
        Console.WriteLine("Evento editado com sucesso!");
        Console.WriteLine("------------------");
    }

    // Método para excluir um evento pelo ID
    static void ExcluirEvento()
    {
        Console.WriteLine("Excluir Evento");
        Console.WriteLine("------------------");

        string id = LerString("ID do Evento: ");
        Evento evento = eventos.Find(e => e.Id == id);

        if (evento == null)
        {
            Console.WriteLine("Evento não encontrado!");
            return;
        }

        eventos.Remove(evento);
        Console.WriteLine("Evento excluído com sucesso!");
        Console.WriteLine("------------------");
    }

    // Método para pesquisar um contato cadastrado
    static void PesquisarContato()
    {
        Console.WriteLine("Pesquisar Contato");
        Console.WriteLine("------------------");

        string nome = LerString("Nome do Contato: ");

        foreach (var evento in eventos)
        {
            if (evento.Responsavel.Nome.Equals(nome, StringComparison.OrdinalIgnoreCase))
            {
                // Exibe as informações do contato encontrado
                Console.WriteLine($"Nome: {evento.Responsavel.Nome}, Telefone: {evento.Responsavel.Telefone}, Email: {evento.Responsavel.Email}");
                return;
            }
        }

        Console.WriteLine("Contato não encontrado.");
        Console.WriteLine("------------------");
    }

    // Método para exportar os dados de um evento para um arquivo TXT
    static void ExportarEventoParaTxt()
    {
        Console.WriteLine("Exportar Evento para TXT");
        Console.WriteLine("------------------");

        string id = LerString("ID do Evento: ");
        Evento evento = eventos.Find(e => e.Id == id);

        if (evento == null)
        {
            Console.WriteLine("Evento não encontrado!");
            return;
        }

        // Cria um arquivo TXT com os dados do evento
        string fileName = $"Evento_{evento.Id}.txt";
        using (StreamWriter writer = new StreamWriter(fileName))
        {
            writer.WriteLine($"ID: {evento.Id}");
            writer.WriteLine($"Título: {evento.Titulo}");
            writer.WriteLine($"Data: {evento.Data.ToShortDateString()}");
            writer.WriteLine($"Horário: {evento.HoraInicial.ToString()} - {evento.HoraFinal.ToString()}");
            writer.WriteLine($"Descrição: {evento.Descricao}");
            writer.WriteLine($"Quantidade de Pessoas: {evento.QuantidadePessoas}");
            writer.WriteLine($"Público Alvo: {evento.PublicoAlvo}");
            writer.WriteLine($"Contato do Responsável:");
            writer.WriteLine($"   Nome: {evento.Responsavel.Nome}");
            writer.WriteLine($"   Telefone: {evento.Responsavel.Telefone}");
            writer.WriteLine($"   Email: {evento.Responsavel.Email}");
        }

        Console.WriteLine($"Evento exportado com sucesso para {fileName}.");
        Console.WriteLine("------------------");
    }

    // Forma para ler uma string do console com uma mensagem de prompt
    static string LerString(string mensagem)
    {
        Console.Write(mensagem);
        return Console.ReadLine();
    }

    // Forma para ler uma data do console com uma mensagem de prompt
    static DateTime LerData(string mensagem)
    {
        DateTime data;
        while (true)
        {
            Console.Write(mensagem);
            if (DateTime.TryParseExact(Console.ReadLine(), "dd/MM/yyyy", null, System.Globalization.DateTimeStyles.None, out data))
                break;
            Console.WriteLine("Data inválida!");
        }
        return data;
    }

    // Forma para ler uma hora do console com uma mensagem de prompt
    static TimeSpan LerHora(string mensagem)
    {
        TimeSpan hora;
        while (true)
        {
            Console.Write(mensagem);
            if (TimeSpan.TryParse(Console.ReadLine(), out hora))
                break;
            Console.WriteLine("Hora inválida!");
        }
        return hora;
    }

    // Forma para ler um inteiro do console com uma mensagem 
    static int LerInt(string mensagem)
    {
        int valor;
        while (true)
        {
            Console.Write(mensagem);
            if (int.TryParse(Console.ReadLine(), out valor))
                break;
            Console.WriteLine("Valor inválido!");
        }
        return valor;
    }

    // Forma de gerar um ID alfanumérico para um evento com tamanho de 6 caracteres
    static string GerarId()
    {
        const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        Random random = new Random();
        return new string(Enumerable.Repeat(chars, 6).Select(s => s[random.Next(s.Length)]).ToArray());
    }
}




